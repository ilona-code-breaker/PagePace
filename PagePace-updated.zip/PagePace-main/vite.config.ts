import tailwindcss from '@tailwindcss/vite';
import react from '@vitejs/plugin-react';
import path from 'path';
import { defineConfig } from 'vite';
import { VitePWA } from 'vite-plugin-pwa';

export default defineConfig(() => {
  return {
    // Relative base so the app works from a GitHub Pages sub-folder
    base: './',
    plugins: [
      react(),
      tailwindcss(),
      VitePWA({
        strategies: 'generateSW',
        filename: 'sw.js',
        registerType: 'autoUpdate',
        // Registration happens only in src/pwa.ts (guarded); never in dev
        injectRegister: null,
        devOptions: { enabled: false },
        includeAssets: ['icons/apple-touch-icon.png'],
        manifest: {
          name: 'PagePace – Reading Tracker',
          short_name: 'PagePace',
          description: 'Track your books, reading pace, streaks and favourite quotes.',
          start_url: './',
          scope: './',
          display: 'standalone',
          background_color: '#0f1117',
          theme_color: '#0f1117',
          icons: [
            { src: 'icons/icon-192.png', sizes: '192x192', type: 'image/png' },
            { src: 'icons/icon-512.png', sizes: '512x512', type: 'image/png' },
            { src: 'icons/icon-maskable-512.png', sizes: '512x512', type: 'image/png', purpose: 'maskable' },
          ],
        },
        workbox: {
          // Hashed build files are precached; pages always try the network first
          globPatterns: ['**/*.{js,css,png,svg,ico,woff2}'],
          navigateFallback: null,
          cleanupOutdatedCaches: true,
          runtimeCaching: [
            {
              urlPattern: ({ request }) => request.mode === 'navigate',
              handler: 'NetworkFirst',
              options: { cacheName: 'pages', networkTimeoutSeconds: 4 },
            },
            {
              urlPattern: ({ url }) => url.origin === 'https://fonts.googleapis.com' || url.origin === 'https://fonts.gstatic.com',
              handler: 'StaleWhileRevalidate',
              options: { cacheName: 'fonts', expiration: { maxEntries: 30 } },
            },
            {
              urlPattern: ({ url }) => url.hostname === 'covers.openlibrary.org' || url.hostname.endsWith('books.google.com'),
              handler: 'CacheFirst',
              options: {
                cacheName: 'book-covers',
                expiration: { maxEntries: 400, maxAgeSeconds: 60 * 60 * 24 * 90 },
                cacheableResponse: { statuses: [0, 200] },
              },
            },
          ],
        },
      }),
    ],
    resolve: {
      alias: {
        '@': path.resolve(process.cwd(), '.'),
      },
    },
    server: {
      hmr: process.env.DISABLE_HMR !== 'true',
      watch: process.env.DISABLE_HMR === 'true' ? null : {},
    },
  };
});
